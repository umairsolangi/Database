<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 800px;
    margin: 50px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

header {
    text-align: center;
}

h1 {
    color: #333;
}

section {
    margin-top: 20px;
}

h2 {
    color: #333;
}

p {
    line-height: 1.6;
    color: #666;
    margin-bottom: 16px;
}

    </style>
</head>
<body>

<div class="container">
    <header>
        <h1>About Us</h1>
    </header>

    <section>
        <h2>UmairSolangi</h2>
        <p>Hello I’m Umair, a certified Front End web developer from Circle.org’s program ‘Tech Karo’ (sponsored by Engro). I've benefited from this course in such a way that now I can build functional web applications with it’s design and responsiveness using trending frameworks and libraries. I’ve a passion to expand my knowledge and grow in this field with experimenting and experiencing. Driven self-starter and fast learner who loves working around robust communities and exchanging trending ideas and tech talks.</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tincidunt urna eget sapien cursus, et hendrerit dui ullamcorper. Integer nec erat ut turpis luctus fringilla ac non ligula. Nullam euismod arcu vel libero feugiat, a eleifend odio volutpat. Integer sagittis ex vel velit ullamcorper, et congue sapien fermentum.</p>

        <p>Feel free to explore our website and discover more about what we offer.</p>
    </section>
</div>

</body>
</html>
