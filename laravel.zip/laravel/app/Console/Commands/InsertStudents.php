<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Student;

class InsertStudents extends Command
{
    protected $signature = 'insert:students';

    protected $description = 'Insert sample data into students table';

    public function handle()
    {
        // Insert your data here
        Student::create([
            'name' => 'John Doe',
            'address' => 'john.doe@example.com',
          
        ]);

        $this->info('Data inserted successfully.');
    }
}

?>