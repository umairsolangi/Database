<h1>This is Umair</h1>
<a href="/about">About Page</a>
<a href="/contact">Contact Page</a><?php /**PATH C:\Users\UmairSolangiCEO\Desktop\lar\umair1\resources\views/welcome.blade.php ENDPATH**/ ?>